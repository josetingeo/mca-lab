lst = [int(x) for x in input("Enter numbers separated by space: ").split()]
print("Sum of list =", sum(lst))
