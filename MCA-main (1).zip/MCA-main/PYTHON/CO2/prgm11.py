square = lambda a: a*a
rectangle = lambda l, w: l*w
triangle = lambda b, h: 0.5*b*h

print("Area of square : ", square(4))
print("Area of rectangle : ", rectangle(5, 3))
print("Area of triangle : ", triangle(6, 4))
