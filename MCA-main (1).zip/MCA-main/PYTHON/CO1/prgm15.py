s1 = input("Enter first String : ")
s2 = input("Enter Second String : ")

new1 = s2[0] + s1[1:]
new2 = s1[0] + s2[1:]

print(new1 + " " + new2)
