import math
a, b = map(int, input("EnterTwo Number : ").split())
print("GCD =", math.gcd(a, b))
