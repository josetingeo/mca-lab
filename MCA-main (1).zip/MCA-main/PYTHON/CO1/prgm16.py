d = {'b': 2, 'a': 1, 'c':3}

print("Ascending:", dict(sorted(d.items())))
print("Descending:", dict(sorted(d.items(), reverse=True)))
