colors = input("Enter colors separated by comma : ").split(",")
print("First Color : ", colors[0])
print("Last Color : ", colors[-1])
