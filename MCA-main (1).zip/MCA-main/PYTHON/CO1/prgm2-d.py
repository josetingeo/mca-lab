word = input("Enter a Word: ")
ordinals = [ord(ch) for ch in word]
print("Ordinal value: ", ordinals)
