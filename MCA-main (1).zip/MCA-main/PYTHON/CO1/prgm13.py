n = int(input("Enter a number: "))
result = n+ int(str(n)*2) + int(str(n)*3)
print("result = ", result)
