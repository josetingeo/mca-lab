filename = input("Enter file name : ")
ext = filename.split(".") [-1]
print("Extension: ", ext)
