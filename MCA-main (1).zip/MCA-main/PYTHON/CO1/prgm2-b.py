N = int(input("Enter N: "))
squares = [x**2 for x in range(1, N+1)]
print("Squares: ", squares)
