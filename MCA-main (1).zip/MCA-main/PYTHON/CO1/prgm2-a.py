numbers = [-3, -1, 0, 2, 4, -5, 7]
positive_numbers = [num for num in numbers if num > 0]
print("positive numbers:",positive_numbers)
