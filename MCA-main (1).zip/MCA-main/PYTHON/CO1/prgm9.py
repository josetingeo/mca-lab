r = float(input("Enter Radius : "))
area = 3.14 * r * r
print("Area Of Circle : ", area)
