a, b, c = map(int, input("Enter 3 Numbers : ").split())
print("Biggest Number Is : ", max(a, b, c))
